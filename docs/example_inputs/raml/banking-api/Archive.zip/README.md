# Banking API Reference Example

This branch contains a reference example for a RAML description for a simple Banking API.
